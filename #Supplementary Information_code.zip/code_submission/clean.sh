#!/bin/bash
rm sim *.txt
